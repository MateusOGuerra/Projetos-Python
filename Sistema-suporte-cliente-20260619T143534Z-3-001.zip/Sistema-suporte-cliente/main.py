def menu():

    while True:

        print("\n=== SISTEMA DE SUPORTE AO CLIENTE ===")
        print("1 - Lista de Produtos")
        print("2 - Endereço")
        print("3 - Horário de Funcionamento")
        print("4 - Falar com Atendente")
        print("5 - Sair")

        opcao = input("\nEscolha uma opção: ")

        if opcao == "1":

        Produtos = [      "Notebook Dell Inspiron",
                "Notebook Lenovo IdeaPad",
                "Mouse Gamer Logitech",
                "Mouse Sem Fio Multilaser",
                "Teclado Mecânico Redragon",
                "Teclado Sem Fio Logitech",
                "Monitor LG 24 polegadas",
                "Monitor Samsung 27 polegadas",
                "Headset HyperX Cloud",
                "Webcam Logitech C920",
                "Impressora Epson EcoTank",
                "SSD Kingston 1TB",
                "Pendrive Sandisk 64GB",
                "Cadeira Gamer",
                "Estabilizador"
                ]

                   print("\n=== LISTA DE PRODUTOS ===\n")

            for i, produto in enumerate(produtos, start=1):
                print(f"{i} - {produto}")

        elif opcao == "2":

            print("\nRua Oratório, 123 - São Paulo")

        elif opcao == "3":

            print("\nSegunda a Sexta: 08h às 18h")

        elif opcao == "4":

              nome = input("Digite seu nome: ")

            with open("clientes.txt", "a", encoding="utf-8") as arquivo:
                arquivo.write(nome + "\n")

            print(f"\nOlá {nome}, um atendente entrará em contato.")

        elif opcao == "5":

            print("\nSistema encerrado.")
            break

        else:

            print("\nOpção inválida!")


menu()